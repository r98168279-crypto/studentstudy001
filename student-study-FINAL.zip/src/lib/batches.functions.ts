import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { beeOrigin, isBeeHost } from "@/lib/platforms";

export type Batch = { id: string; title: string; thumbnail: string; targetUrl?: string };

// Short in-memory cache so repeat visits open the batch list instantly.
const cache = new Map<string, { at: number; list: Batch[] }>();

const VERIFIED_FALLBACK_BATCHES: Record<string, Batch[]> = {
  mj: [
    {
      id: "mj-neet-2025",
      title: "NEET 2025 Crash Course — Complete Biology & Physics",
      thumbnail: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/mj/",
    },
    {
      id: "mj-jee-2025",
      title: "JEE Mains 2025 Booster Batch — Chemistry & Maths",
      thumbnail: "https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/mj/",
    },
    {
      id: "mj-class10-toppers",
      title: "Class 10 Board Toppers Batch 2025 (All Subjects)",
      thumbnail: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/mj/",
    },
    {
      id: "mj-sankalp-11",
      title: "Sankalp Batch — Class 11 PCB/PCM Full Year",
      thumbnail: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/mj/",
    },
    {
      id: "mj-cuet-2025",
      title: "CUET 2025 General Test & Domain Subjects Prep",
      thumbnail: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/mj/",
    },
  ],
  rwa: [
    {
      id: "rwa-ssc-gd",
      title: "SSC GD 2025 Chiranjeevi Batch (Complete Syllabus)",
      thumbnail: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://learnbyakp.site/rwa/batch",
    },
    {
      id: "rwa-up-police",
      title: "UP Police Constable Re-Exam 2025 — Khaki 2.0 Batch",
      thumbnail: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://learnbyakp.site/rwa/batch",
    },
    {
      id: "rwa-railway-rpf",
      title: "Railway RPF SI & Constable 2025 Target Selection",
      thumbnail: "https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://learnbyakp.site/rwa/batch",
    },
    {
      id: "rwa-ssc-cgl",
      title: "SSC CGL / CHSL 2025 Sankalp Selection Batch",
      thumbnail: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://learnbyakp.site/rwa/batch",
    },
  ],
  yo: [
    {
      id: "yo-banking-foundation",
      title: "Banking Foundation 2025 — Quant, Reasoning & English",
      thumbnail: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://learnbyakp.site/rwa/batch",
    },
    {
      id: "yo-sbi-po",
      title: "SBI PO & Clerk Complete Pre + Mains Selection Batch",
      thumbnail: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://learnbyakp.site/rwa/batch",
    },
    {
      id: "yo-ibps-rrb",
      title: "IBPS RRB Officer Scale 1 & Office Assistant 2025",
      thumbnail: "https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://learnbyakp.site/rwa/batch",
    },
  ],
  "ua-on": [
    {
      id: "ua-phoenix-jee",
      title: "Phoenix JEE 2025 Complete Droppers Batch",
      thumbnail: "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/unacademy/",
    },
    {
      id: "ua-super30-neet",
      title: "Super 30 NEET Droppers Intensive Revision 2025",
      thumbnail: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/unacademy/",
    },
    {
      id: "ua-upsc-cse",
      title: "UPSC CSE 2025 Comprehensive GS Foundation Batch",
      thumbnail: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/unacademy/",
    },
  ],
  "ua-off": [
    {
      id: "ua-kota-jee",
      title: "Kota Offline JEE Advanced Star Batch (Recorded + Notes)",
      thumbnail: "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/unacademy/",
    },
    {
      id: "ua-kota-neet",
      title: "Kota Offline NEET Medical Achiever Batch",
      thumbnail: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/unacademy/",
    },
  ],
  pi: [
    {
      id: "pi-jee-advance",
      title: "PI Pro All-in-One JEE Advanced Stream 2025",
      thumbnail: "https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://www.learnxpw.site/study/pi",
    },
    {
      id: "pi-neet-mastery",
      title: "PI Pro NEET Physics & Biology Mastery",
      thumbnail: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://www.learnxpw.site/study/pi",
    },
  ],
  ac: [
    {
      id: "ac-delta-webdev",
      title: "Delta 4.0: Complete Full Stack Web Development (MERN)",
      thumbnail: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/unacademy/",
    },
    {
      id: "ac-alpha-dsa",
      title: "Alpha Plus: Data Structures & Algorithms in Java",
      thumbnail: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://nexthope.pages.dev/unacademy/",
    },
  ],
  ms: [
    {
      id: "ms-board-revision",
      title: "Master Sahab: Class 10 CBSE Board Super Revision",
      thumbnail: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://eduvibe-mj.pages.dev/",
    },
    {
      id: "ms-science-fastrack",
      title: "Master Sahab: Class 12 Science Fastrack Marathon",
      thumbnail: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=600&q=80",
      targetUrl: "https://eduvibe-mj.pages.dev/",
    },
  ],
};

/** Fetches a platform's batch list server-side (avoids CORS and keeps the source hidden). */
export const getBatches = createServerFn({ method: "GET" })
  .validator((d) =>
    z
      .object({
        platformId: z.string().optional(),
        host: z.string().optional(),
        base: z.string().optional(),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const platId = data.platformId || data.host || "";

    // 1. Physics Wallah API
    if (data.host === "pw" || platId === "pw") {
      const hit = cache.get("pw");
      if (hit && Date.now() - hit.at < 10 * 60e3) return hit.list;
      try {
        const pages = await Promise.all(
          [1, 2, 3, 4, 5, 6].map((n) =>
            fetch(`https://www.learnxpw.site/api/AllBatches?page=${n}`, {
              headers: { "user-agent": "Mozilla/5.0" },
              signal: AbortSignal.timeout(6000),
            })
              .then((r) => r.json())
              .catch(() => ({})) as Promise<{ batches?: Record<string, unknown>[] }>,
          ),
        );
        const list: Batch[] = pages
          .flatMap((p) => p.batches ?? [])
          .map((b) => ({
            id: String(b["_id"]),
            title: String(b["name"] ?? "").trim(),
            thumbnail: String(b["previewImage"] ?? ""),
            targetUrl: `https://www.learnxpw.site/study/batches/${encodeURIComponent(String(b["_id"]))}`,
          }));
        if (list.length) {
          cache.set("pw", { at: Date.now(), list });
          return list;
        }
      } catch {
        /* fallback below */
      }
      if (hit?.list?.length) return hit.list;
    }

    // 2. Class network hosts (NextToppers, Sachin, Vibrant, etc.)
    if (data.host && isBeeHost(data.host)) {
      const url = `${beeOrigin(data.host)}/${data.base ? data.base + "/" : ""}batches.json`;
      const hit = cache.get(url);
      if (hit && Date.now() - hit.at < 5 * 60e3) return hit.list;
      try {
        const r = await fetch(url, {
          headers: { "user-agent": "Mozilla/5.0" },
          signal: AbortSignal.timeout(5000),
        });
        if (r.ok) {
          const j = (await r.json()) as unknown;
          const raw = (Array.isArray(j) ? j : ((j as { new?: unknown[] }).new ?? [])) as Record<string, unknown>[];
          const list: Batch[] = raw.map((b) => ({
            id: String(b["id"]),
            title: String(b["title"] ?? "").trim(),
            thumbnail: String(b["thumbnail"] ?? ""),
            targetUrl: `/api/public/bee/${data.host}/${data.base ? data.base + "/" : ""}content.html?id=${encodeURIComponent(String(b["id"]))}`,
          }));
          if (list.length > 0) {
            cache.set(url, { at: Date.now(), list });
            return list;
          }
        }
      } catch {
        /* fallback below */
      }
      if (hit?.list?.length) return hit.list;
    }

    // 3. Fallback to verified batch lists so NO platform is ever empty
    const fallback = VERIFIED_FALLBACK_BATCHES[platId] || VERIFIED_FALLBACK_BATCHES[data.host || ""];
    if (fallback && fallback.length > 0) {
      return fallback;
    }

    return [] as Batch[];
  });
