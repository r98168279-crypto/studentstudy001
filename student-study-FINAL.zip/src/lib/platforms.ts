export type Platform = {
  id: string;
  name: string;
  tag: string;
  tagline: string;
  mirrors: { label: string; url: string }[];
  subjects: string[];
  status: "online" | "internal" | "soon";
  domain?: string;
  hue: number;
  /** Batch source on the class network: host key, optional sub-folder, and page that opens a batch. */
  bee?: { host: string; base?: string; page?: string };
};

// Aapke Telegram Links (inhe chahein toh apne hisab se update karein)
export const TELEGRAM_COMMUNITY = "https://t.me/+04xCA1ldNEozOWI1"; // Discussion Group
export const TELEGRAM_CHANNEL = "https://t.me/studentstudy012";     // Main Updates Channel
export const ENROLL_KEY = "student_study_enrolled_batches";

const JEE = ["Physics", "Chemistry", "Maths"];
const NEET = ["Physics", "Chemistry", "Biology"];

export const PLATFORMS: Platform[] = [
  {
    id: "nt",
    bee: { host: "nt" },
    hue: 25,
    domain: "nexttoppers.com",
    name: "Next Toppers",
    tag: "NT",
    tagline: "Class 9–12 toppers batches",
    status: "online",
    subjects: ["Science", "Maths", "SST", "English"],
    mirrors: [
      { label: "Mirror 1", url: "https://www.learnxpw.site/study/nexttoppers" },
      { label: "Mirror 2", url: "https://eduvibe-nt.pages.dev/" },
    ],
  },
  {
    id: "pw",
    bee: { host: "pw" },
    hue: 260,
    domain: "pw.live",
    name: "Physics Wallah",
    tag: "PW",
    tagline: "JEE · NEET · Foundation batches",
    status: "online",
    subjects: [...JEE, "Biology"],
    mirrors: [{ label: "Mirror 1", url: "https://www.learnxpw.site/study/batches" }],
  },
  {
    id: "mj",
    bee: { host: "www", base: "mj" },
    hue: 145,
    domain: "missionjeet.in",
    name: "Mission Jeet",
    tag: "MJ",
    tagline: "Board + competitive prep",
    status: "online",
    subjects: ["Science", "Maths", "SST"],
    mirrors: [
      { label: "Mirror 1", url: "https://nexthope.pages.dev/mj/" },
      { label: "Mirror 2", url: "https://eduvibe-mj.pages.dev/" },
    ],
  },
  {
    id: "rwa",
    bee: { host: "rwa", base: "rwax", page: "subject.html" },
    hue: 15,
    domain: "rojgarwithankit.co.in",
    name: "Rojgar With Ankit",
    tag: "RWA",
    tagline: "SSC · Railway · Govt exams",
    status: "online",
    subjects: ["Maths", "Reasoning", "English", "GK/GS"],
    mirrors: [{ label: "Mirror 1", url: "https://learnbyakp.site/rwa/batch" }],
  },
  {
    id: "sa",
    bee: { host: "sachin" },
    hue: 180,
    domain: "sachinacademy.com",
    name: "Sachin Academy",
    tag: "SA",
    tagline: "KVS · Teaching exams",
    status: "online",
    subjects: ["CDP", "Pedagogy", "Hindi"],
    mirrors: [{ label: "Mirror 1", url: "https://sachin.studybeepro.site" }],
  },
  {
    id: "yo",
    bee: { host: "yesofficer" },
    hue: 220,
    domain: "yesofficer.com",
    name: "Yes Officer",
    tag: "YO",
    tagline: "Govt exams · Police · SSC",
    status: "online",
    subjects: ["Reasoning", "Maths", "English"],
    mirrors: [{ label: "Mirror 1", url: "https://learnbyakp.site/rwa/batch" }],
  },
  {
    id: "pi",
    bee: { host: "www", base: "pi" },
    hue: 200,
    domain: "learnxpw.site",
    name: "PI Pro",
    tag: "PI",
    tagline: "JEE · NEET internal stream",
    status: "online",
    subjects: JEE,
    mirrors: [{ label: "Mirror 1", url: "https://www.learnxpw.site/study/pi" }],
  },
  {
    id: "vb",
    bee: { host: "www", base: "vibrante" },
    hue: 320,
    domain: "vibrantacademy.com",
    name: "Vibrant Academy",
    tag: "VB",
    tagline: "IIT-JEE Top Rankers Gateway",
    status: "online",
    subjects: JEE,
    mirrors: [{ label: "Mirror 1", url: "https://www.learnxpw.site/vibrant" }],
  },
  {
    id: "ua-on",
    bee: { host: "www", base: "unacademy" },
    hue: 160,
    domain: "unacademy.com",
    name: "Unacademy Online",
    tag: "UA-ON",
    tagline: "Live + recorded classes",
    status: "online",
    subjects: NEET,
    mirrors: [{ label: "Mirror 1", url: "https://nexthope.pages.dev/unacademy/" }],
  },
  {
    id: "ua-off",
    bee: { host: "www", base: "unacademy" },
    hue: 130,
    domain: "unacademy.com",
    name: "Unacademy Offline",
    tag: "UA-OFF",
    tagline: "Kota offline top batches",
    status: "online",
    subjects: NEET,
    mirrors: [{ label: "Mirror 1", url: "https://nexthope.pages.dev/unacademy/" }],
  },
  {
    id: "ms",
    bee: { host: "www", base: "ms" },
    hue: 55,
    domain: "youtube.com",
    name: "Master Sahab",
    tag: "MS",
    tagline: "Board & competition marathon",
    status: "online",
    subjects: ["Board Exams", "Physics", "Chemistry"],
    mirrors: [{ label: "Mirror 1", url: "https://eduvibe-mj.pages.dev/" }],
  },
  {
    id: "ac",
    bee: { host: "www", base: "ac" },
    hue: 295,
    domain: "apnacollege.in",
    name: "Apna College",
    tag: "AC",
    tagline: "Coding · DSA · Web Dev",
    status: "online",
    subjects: ["DSA", "Web Dev"],
    mirrors: [{ label: "Mirror 1", url: "https://nexthope.pages.dev/unacademy/" }],
  },
];

export const getPlatform = (id: string) => PLATFORMS.find((p) => p.id === id);

export function readEnrolled(): string[] {
  try { return JSON.parse(localStorage.getItem(ENROLL_KEY) || "[]"); } catch { return []; }
}
export function writeEnrolled(ids: string[]) {
  localStorage.setItem(ENROLL_KEY, JSON.stringify(ids));
}

const BEE_HOSTS = ["nt", "yesofficer", "sachin", "rwa", "www", "vidya", "scienceandfun", "pw"];
export const isBeeHost = (h: string) => BEE_HOSTS.includes(h);
export const beeOrigin = (h: string) => (h === "www" ? "https://studybeepro.site" : `https://${h}.studybeepro.site`);
