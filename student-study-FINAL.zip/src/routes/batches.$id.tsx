import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Check, ExternalLink, Plus, Search, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getPlatform } from "@/lib/platforms";
import { getBatches, type Batch } from "@/lib/batches.functions";
import { PlatformLogo } from "@/components/PlatformLogo";
import { KeyGate } from "@/components/KeyGate";
import { readUnlock } from "@/lib/unlock";

export const Route = createFileRoute("/batches/$id")({
  head: () => ({
    meta: [
      { title: "Batches — Student Study" },
      { name: "description", content: "Saare free batches ek jagah — search, enroll aur padhai shuru karo." },
      { property: "og:title", content: "Batches — Student Study" },
      { property: "og:description", content: "Saare free batches ek jagah — search, enroll aur padhai shuru karo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ params }) => {
    const p = getPlatform(params.id);
    return getBatches({
      data: {
        platformId: params.id,
        host: p?.bee?.host ?? params.id,
        base: p?.bee?.base,
      },
    });
  },
  component: BatchesPage,
});

const ENR = "student_study_enrolled_bee";

function BatchesPage() {
  const { id } = Route.useParams();
  const batches = Route.useLoaderData();
  const p = getPlatform(id);
  const [q, setQ] = useState("");
  const [tab, setTab] = useState<"all" | "enr">("all");
  const [enr, setEnr] = useState<string[]>([]);
  const [shown, setShown] = useState(12);
  const [gate, setGate] = useState<string | null>(null);

  useEffect(() => {
    try {
      setEnr(JSON.parse(localStorage.getItem(ENR) || "[]"));
    } catch {
      /* ignore */
    }
  }, []);

  const key = (b: Batch) => `${id}:${b.id}`;
  const toggle = (b: Batch) => {
    const n = enr.includes(key(b)) ? enr.filter((x) => x !== key(b)) : [...enr, key(b)];
    setEnr(n);
    localStorage.setItem(ENR, JSON.stringify(n));
  };

  const list = useMemo(
    () =>
      batches.filter(
        (b) =>
          (tab === "all" || enr.includes(key(b))) &&
          b.title.toLowerCase().includes(q.toLowerCase()),
      ),
    [batches, q, tab, enr],
  );

  const [play, setPlay] = useState<{ url: string; title: string } | null>(null);

  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      if (e.origin === window.location.origin && e.data === "ss-close") setPlay(null);
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const openBatch = (b: Batch) => {
    let targetUrl = b.targetUrl;

    if (!targetUrl) {
      const bee = p?.bee;
      if (bee?.host === "pw") {
        targetUrl = `https://www.learnxpw.site/study/batches/${encodeURIComponent(b.id)}`;
      } else if (bee) {
        targetUrl = `/api/public/bee/${bee.host}/${bee.base ? bee.base + "/" : ""}${bee.page ?? "content.html"}?id=${encodeURIComponent(b.id)}`;
      } else if (p?.mirrors && p.mirrors.length > 0) {
        targetUrl = p.mirrors[0].url;
      }
    }

    if (!targetUrl) {
      targetUrl = "https://www.learnxpw.site/study/batches";
    }

    const v = { url: targetUrl, title: b.title };

    // Agar key unlocked hai to class seedha open hogi:
    if (readUnlock()) {
      setPlay(v);
    } else {
      setGate(JSON.stringify(v));
    }
  };

  if (!p) {
    return (
      <main className="p-8 text-center font-mono">
        Platform nahi mila.{" "}
        <Link to="/study" className="text-primary underline">
          Wapas jayein
        </Link>
      </main>
    );
  }

  // Key required screen:
  if (gate) {
    return (
      <KeyGate
        onUnlock={() => {
          setPlay(JSON.parse(gate));
          setGate(null);
        }}
        onCancel={() => setGate(null)}
      />
    );
  }

  // In-site Fullscreen Video Classroom:
  if (play) {
    return (
      <main className="fixed inset-0 z-50 flex h-screen w-screen flex-col bg-background">
        <div className="flex h-12 items-center justify-between border-b border-border/50 bg-card/90 px-4 backdrop-blur">
          <div className="flex items-center gap-3 overflow-hidden">
            <Button size="sm" variant="cyber" onClick={() => setPlay(null)}>
              <ArrowLeft className="h-4 w-4" /> Wapas
            </Button>
            <span className="truncate font-display text-sm font-bold text-primary">
              {play.title}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={play.url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 rounded border border-primary/40 bg-primary/10 px-2.5 py-1 font-mono text-[11px] text-primary hover:bg-primary/20 transition-colors"
            >
              Pop-out <ExternalLink className="h-3 w-3" />
            </a>
            <span className="rounded border border-primary/40 bg-primary/10 px-2 py-0.5 font-mono text-[11px] text-primary hidden sm:inline">
              STUDENT STUDY
            </span>
          </div>
        </div>
        <iframe
          src={play.url}
          title={play.title}
          className="h-[calc(100vh-48px)] w-full border-0 bg-background"
          allow="fullscreen; autoplay; encrypted-media; picture-in-picture; screen-wake-lock; orientation"
          allowFullScreen
        />
      </main>
    );
  }

  return (
    <main
      className="mx-auto max-w-6xl space-y-6 px-4 py-6"
      style={{ "--brand-h": p.hue } as React.CSSProperties}
    >
      <div className="flex items-center justify-between">
        <Link to="/study" className="inline-flex items-center gap-2 font-mono text-xs text-primary">
          <ArrowLeft className="h-4 w-4" /> Study Hub
        </Link>
        <span className="inline-flex items-center gap-1 font-mono text-[11px] text-primary">
          <Sparkles className="h-3 w-3" /> All Batches Live
        </span>
      </div>

      <div className="flex items-center gap-3">
        <PlatformLogo p={p} size={52} />
        <div>
          <h1 className="text-xl font-black">{p.name}</h1>
          <p className="text-xs text-muted-foreground">{batches.length} batches available</p>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="Search batch (e.g. Lakshya, Yakeen, Class 10, Sankalp...)"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </div>

      <div className="flex gap-2">
        <Button
          size="sm"
          variant={tab === "all" ? "neon" : "cyber"}
          onClick={() => setTab("all")}
        >
          All Batches ({batches.length})
        </Button>
        <Button
          size="sm"
          variant={tab === "enr" ? "neon" : "cyber"}
          onClick={() => setTab("enr")}
        >
          My Enrolled ({batches.filter((b) => enr.includes(key(b))).length})
        </Button>
      </div>

      {list.length === 0 && (
        <div className="cyber-card p-8 text-center text-sm text-muted-foreground">
          Koi batch nahi mila ya batch list load ho rahi hai...
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {list.slice(0, shown).map((b) => (
          <div key={b.id} className="cyber-card brand-card overflow-hidden">
            <div className="relative aspect-video bg-muted">
              {b.thumbnail ? (
                <img
                  src={b.thumbnail}
                  alt={b.title}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center font-mono text-xs text-muted-foreground">
                  {p.name}
                </div>
              )}
              <span className="absolute right-2 top-2 rounded bg-background/80 px-2 py-0.5 font-mono text-[10px] text-primary backdrop-blur">
                FREE
              </span>
            </div>
            <div className="space-y-3 p-3">
              <h3 className="line-clamp-2 text-sm font-bold">{b.title}</h3>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="cyber"
                  className="flex-1"
                  onClick={() => toggle(b)}
                >
                  {enr.includes(key(b)) ? (
                    <>
                      <Check className="h-4 w-4" /> ENROLLED
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4" /> ENROLL
                    </>
                  )}
                </Button>
                {/* Seedha website ke andar class open karne wala single button */}
                <Button
                  size="sm"
                  variant="neon"
                  className="flex-1"
                  onClick={() => openBatch(b)}
                >
                  LET'S STUDY →
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {shown < list.length && (
        <Button
          variant="cyber"
          className="w-full"
          onClick={() => setShown(shown + 12)}
        >
          Load More Batches
        </Button>
      )}
    </main>
  );
}
